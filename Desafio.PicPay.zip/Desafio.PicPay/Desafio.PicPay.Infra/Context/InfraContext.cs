﻿using Desafio.PicPay.Domain.Entities;
using MongoDB.Driver;
using System;
using System.Configuration;


namespace Desafio.PicPay.Infra.Context
{
    public class InfraContext : IDisposable
    {
        public IMongoDatabase DataBase { get; private set; }

        public InfraContext() 
        {
            var connectionString = ConfigurationManager.AppSettings["MongoDBConectionString"];
            var client = new MongoClient(connectionString);
            var databaseName = ConfigurationManager.AppSettings["MongoDBDatabaseName"];
            DataBase = client.GetDatabase(databaseName);
        }

        public void Dispose()
        {
            if (DataBase != null)
                DataBase = null;
        }
    }
}