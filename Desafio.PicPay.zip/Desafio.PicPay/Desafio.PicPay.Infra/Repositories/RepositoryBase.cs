﻿using Desafio.PicPay.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Desafio.PicPay.Domain.Helper;
using Desafio.PicPay.Infra.Context;

namespace Desafio.PicPay.Infra.Repositories
{
    public class RepositoryBase<TEntity> : IDisposable, IRepositoryBase<TEntity> where TEntity : class
    {
        protected InfraContext Context;

        public RepositoryBase(InfraContext context)
        {
            Context = context;
        }

        public virtual TEntity Add(TEntity obj)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            if(Context != null)
                Context.Dispose();
        }

        public virtual IEnumerable<TEntity> GetAll()
        {
            throw new NotImplementedException();
        }

        public virtual TEntity GetById(int id)
        {
            throw new NotImplementedException();
        }

        public virtual IPagedList<TEntity> GetPaged(int pageSize, int pageNumber)
        {
            throw new NotImplementedException();
        }

        public virtual void Remove(TEntity obj)
        {
            throw new NotImplementedException();
        }

        public virtual TEntity Update(TEntity obj)
        {
            throw new NotImplementedException();
        }
    }
}
