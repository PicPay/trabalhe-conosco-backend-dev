﻿using Desafio.PicPay.Domain.Entities;
using Desafio.PicPay.Domain.Helper;
using Desafio.PicPay.Domain.Interfaces;
using Desafio.PicPay.Infra.Context;
using Desafio.PicPay.Infra.Helpers;
using System.Collections.Generic;
using System.Linq;
using System;
using MongoDB.Driver;

namespace Desafio.PicPay.Infra.Repositories
{
    public class UserRepository : RepositoryBase<User>, IUserRepository
    {
        public UserRepository(InfraContext context) : base(context)
        {
        }       

        public IPagedList<User> SearchPaged(string names, string username, int pageSize, int pageNumber)
        {
            // Tratamento para não buscar por páginas com valor negativo
            if (pageNumber <= 0)
                pageNumber = 1;

            var _collection = this.Context.DataBase.GetCollection<User>("usuarios");

            // Filtro por TAG
            var builder = Builders<User>.Filter;
            var filter = FilterDefinition<User>.Empty;

            // Cria o critério da consulta pelas tags names
            if (names != null && names.Length > 0)
            {
                foreach (var name in names.Split(' '))
                {                    
                    filter = filter & builder.Eq("tags", name.ToLower());
                }
            }

            // Cria o critério da consulta pelo username
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(names))
            {
                filter = filter & builder.Regex("username", username.ToLower());
            }
            else if (!string.IsNullOrEmpty(username) && string.IsNullOrEmpty(names))
            {
                filter = filter & builder.Eq("username", username.ToLower());
            }

            // Busca o total de registros encontrados na consulta
            var totalRecords = _collection
                                .Count(filter);

            // Busca a coleção de registros
            var records = _collection
                        .Find(filter) // Filtro
                        .Sort(Builders<User>.Sort.Ascending("priority").Ascending("name")) // Ordenação
                        .Skip((pageNumber - 1) * pageSize)
                        .Limit(15)
                        .ToList();

            // Criar e retorna o objeto de paginação
            return new PagedList<User>(pageSize, pageNumber, (int)totalRecords, records);
        }
    }
}