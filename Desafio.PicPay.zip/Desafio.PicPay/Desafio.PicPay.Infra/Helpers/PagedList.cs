﻿using Desafio.PicPay.Domain.Helper;
using System;
using System.Collections.Generic;

namespace Desafio.PicPay.Infra.Helpers
{
    public class PagedList<T> : IPagedList<T> where T : class
    {
        public IEnumerable<T> Content { get; set; }

        public int CurrentPage { get; set; }

        public int PageSize { get; set; }

        public int TotalRecords { get; set; }

        public int TotalPages { get; set; }

        public PagedList(int pageSize, int pageNumber, int totalRecords, IEnumerable<T> content)
        {
            PageSize = pageSize;
            CurrentPage = pageNumber;
            TotalRecords = totalRecords;
            TotalPages = (int)Math.Ceiling((decimal)totalRecords / PageSize);
            Content = content;
        }
    }
}