﻿using Desafio.PicPay.Domain.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Desafio.PicPay.Domain.Interfaces
{
    public interface IRepositoryBase<TEntity> where TEntity : class
    {
        TEntity Add(TEntity obj);
        TEntity GetById(int id);
        IEnumerable<TEntity> GetAll();
        IPagedList<TEntity> GetPaged(int pageSize, int pageNumber);
        TEntity Update(TEntity obj);
        void Remove(TEntity obj);
        void Dispose();
    }
}
