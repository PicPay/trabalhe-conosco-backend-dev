﻿using Desafio.PicPay.Domain.Entities;
using Desafio.PicPay.Domain.Helper;

namespace Desafio.PicPay.Domain.Interfaces
{
    public interface IUserRepository : IRepositoryBase<User>
    {
        IPagedList<User> SearchPaged(string name, string username, int pageSize, int pageNumber);
    }
}