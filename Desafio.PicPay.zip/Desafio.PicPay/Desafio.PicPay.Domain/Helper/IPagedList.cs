﻿using System.Collections.Generic;

namespace Desafio.PicPay.Domain.Helper
{
    public interface IPagedList<T> where T : class
    {
        IEnumerable<T> Content { get; set; }
        int CurrentPage { get; set; }
        int PageSize { get; set; }
        int TotalRecords { get; set; }
        int TotalPages { get; set; }
    }
}