﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Desafio.PicPay.Domain.Entities
{
    public class User
    {
        [MongoDB.Bson.Serialization.Attributes.BsonId]
        public ObjectId _id { get; set; }

        [BsonElement("id")]
        public string id { get; set; }

        [BsonElement("name")]
        public string name { get; set; }

        [BsonElement("username")]
        public string username { get; set; }

        [BsonElement("tags")]
        public string[] tags { get; set; }

        [BsonElement("priority")]
        public Double priority { get; set; }
    }
}