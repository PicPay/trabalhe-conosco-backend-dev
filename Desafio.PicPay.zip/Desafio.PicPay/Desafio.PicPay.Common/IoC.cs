﻿using Desafio.PicPay.Domain.Interfaces;
using Desafio.PicPay.Infra.Context;
using Desafio.PicPay.Infra.Repositories;
using SimpleInjector;
using System;

namespace Desafio.PicPay.Common
{
    public class IoC
    {
        private static Container _container;

        public static void RegisterServices(Container container)
        {
            _container = container;

            // TODO: Implementar os modulos
            RegisterInfra();
            RegisterDomainRepository();
        }

        /// <summary>
        /// Faz a injeção de depêndencia para as classes da INFRA
        /// </summary>
        private static void RegisterInfra()
        {
            _container.Register<InfraContext>(Lifestyle.Scoped);
        }

        /// <summary>
        /// Faz a injeção de depêndencia para as classes do repositório de DOMÍNIO
        /// </summary>
        private static void RegisterDomainRepository()
        {
            _container.Register<IUserRepository, UserRepository>(Lifestyle.Scoped);
        }

        public static object GetInstance(Type type)
        {
            return _container.GetInstance(type);
        }
    }
}