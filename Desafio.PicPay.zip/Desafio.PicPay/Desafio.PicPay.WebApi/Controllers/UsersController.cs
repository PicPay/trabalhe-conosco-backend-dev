﻿using Desafio.PicPay.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApi.OutputCache.V2;

namespace Desafio.PicPay.WebApi.Controllers
{
    [Authorize]
    public class UsersController : ApiController
    {
        private readonly IUserRepository _usersRepository;

        public UsersController(IUserRepository usersRepository)
        {
            this._usersRepository = usersRepository;
        }

        [HttpGet]
        [CacheOutput(ServerTimeSpan = 120)]
        public HttpResponseMessage Search(string name, string userName, int page = 0)
        {
            if (string.IsNullOrEmpty(name) && string.IsNullOrEmpty(userName))
                return Request.CreateResponse(HttpStatusCode.OK, new { recordsPaged = new { } });

            var records = _usersRepository.SearchPaged(name, userName, 15, page);
            return Request.CreateResponse(HttpStatusCode.OK, new { recordsPaged = records });
        }
    }
}
