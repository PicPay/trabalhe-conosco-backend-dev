﻿var app = angular.module("mainModule", ["authModule"]);

// Serviço de gerenciamento de requisições
app.service("mainService", function ($http) {
    "use strict"

    this.getPaged = function (user, username, pageNumber) {
        return $http.get(window.location.origin + '/api' + "/users/Search?name="+ user +"&username="  +username + "&page=" + pageNumber)
    }
});

// Controller principal
app.controller("mainController", ["$scope", "mainService", "authService", function ($scope, mainService, authService) {
    "use strict";

    $scope.query = {};

    // Executa a requisção de busca por palavras chaves
    $scope.search = function (pageNumber) {

        $scope.recordsPaged = {};
        $scope.recordsPaged.pagesArray = [];
        $scope.isLoading = true;

        if ($scope.query.name == null)
            $scope.query.name = "";

        if ($scope.query.username == null)
            $scope.query.username = "";

        console.log($scope.query);
        // Faz a requisição para a API
        var request = mainService.getPaged($scope.query.name, $scope.query.username, pageNumber);

        request.then(function (response) {
            // Sucesso
            // Dados paginados vindos da API
            $scope.recordsPaged = response.data.recordsPaged;
            
            // Cria um array com o total de páginas da consulta
            $scope.recordsPaged.pagesArray = BuildPageArray($scope.recordsPaged.CurrentPage, $scope.recordsPaged.PageSize, $scope.recordsPaged.TotalRecords);

            $scope.isLoading = false;
        }, function (error) {

            alert("Falha na requisição.");
            console.log(error);
            $scope.isLoading = false;
        });
    }
   
    // Executa a requisição de autenticação
    $scope.login = function () {

        // Fixei o usuário e senha apenas para realizar a demonstração da funcionalidade
        authService.logIn("picpay", "picpay",
            function () {
               
                $scope.isAuthenticated = true;
            },
            function () {
                
                $scope.isAuthenticated = false;
            });

    }

    function BuildPageArray(currentIndex, itensPerPage, totalItens) {
        var pages = [];

        var valor = totalItens - (currentIndex + itensPerPage);

        if (valor < 0)
        {
            for (var i = (currentIndex + valor); i < (currentIndex + valor) + itensPerPage; i++)
            {
                if((i + 1) > 0)
                    pages.push(i + 1);
            }
        }
        else
        {
            var temp = Math.ceil(totalItens / itensPerPage);

            for (var i = 1; i < temp; i++)
            {
                if ((i * itensPerPage) == currentIndex)
                {
                    for (var j = currentIndex; j < currentIndex + itensPerPage + 1; j++)
                    {
                        pages.push(j);
                    }
                }
                else if (currentIndex < (i * itensPerPage) && currentIndex > ((i - 1) * itensPerPage))
                {
                    var range = (i - 1) * itensPerPage;
                    var startItem = range == 0 ? 1 : range;

                    for (var j = startItem; j < range + itensPerPage + 1; j++)
                    {
                        pages.push(j);
                    }
                }
            }
        }

        return pages;
    }
}]);


app.run(['$http', '$window', function ($http, $window) {
    "use strict"

    $http.defaults.headers.common['Authorization'] = "Bearer " + $window.sessionStorage.getItem("authenticationToken");
}]);