﻿var appAuth = angular.module("authModule", []);

appAuth.config(function () {});

appAuth.service("authService", function ($http, $window) {
    "use strict"

    this.logIn = function (username, password, callbackSuccess, callbackError) {

        var authurl = window.location.origin + '/api' + "/security/token";
        var data = "grant_type=password&" +
                    "username=" + username +
                    "&password=" + password;

        $http.post(authurl, data, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
            .then(function (result) {

                $window.sessionStorage.setItem("authenticationToken", result.data.access_token.replace('"', ''));
                callbackSuccess();
            },
            function () {
                callbackError();
            });
    }

    this.logOut = function () {
        $window.sessionStorage.removeItem("authenticationToken");
    }

    this.isAuthenticated = function () {
        var token = $window.sessionStorage.getItem("authenticationToken");
        return (token == null)
    }
});