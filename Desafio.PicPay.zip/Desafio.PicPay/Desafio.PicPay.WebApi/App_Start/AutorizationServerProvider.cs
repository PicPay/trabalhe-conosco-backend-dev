﻿using Microsoft.Owin.Security.OAuth;
using System;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Desafio.PicPay.WebApi
{
    public class AutorizationServerProvider : OAuthAuthorizationServerProvider
    {
        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
        }

        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { "*" });

            try
            {
                var user = context.UserName;
                var password = HashMD5(context.Password);

                var IsAutenticationValid = user == "picpay" && password == HashMD5("picpay");

                if (IsAutenticationValid)
                {
                    var identity = new ClaimsIdentity(context.Options.AuthenticationType);
                    identity.AddClaim(new Claim(ClaimTypes.Name, "PicPay"));
                    identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, Guid.NewGuid().ToString()));

                    GenericPrincipal principal = new GenericPrincipal(identity, new string[0]);

                    context.Validated(identity);
                }
                else
                {
                    var message = "Autenticação inválida.";
                    context.SetError("invalid_grant", message);
                    throw new Exception(message);
                }
            }
            catch (Exception ex)
            {
                context.SetError("invalid_grant", "Falha na autenticação: " + ex.Message);
                throw new Exception(ex.Message);
            }
        }


        public static string HashMD5(string pValue)
        {
            string SALT_VALUE = "*dHJ%3b5gj8K#cX";
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] encodedBytes = md5.ComputeHash(ASCIIEncoding.Default.GetBytes(String.Concat(pValue, SALT_VALUE)));

            return BitConverter.ToString(encodedBytes);
        }
    }
}